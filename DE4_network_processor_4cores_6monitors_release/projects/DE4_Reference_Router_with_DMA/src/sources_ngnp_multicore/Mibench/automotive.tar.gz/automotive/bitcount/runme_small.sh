#!/bin/sh
bitcnts 75000 > output_small.txt
