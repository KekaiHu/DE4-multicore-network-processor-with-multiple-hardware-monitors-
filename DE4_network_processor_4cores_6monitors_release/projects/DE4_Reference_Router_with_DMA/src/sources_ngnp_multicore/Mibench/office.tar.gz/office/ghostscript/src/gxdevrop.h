/* Copyright (C) 1996 Aladdin Enterprises.  All rights reserved.
  
  This file is part of Aladdin Ghostscript.
  
  Aladdin Ghostscript is distributed with NO WARRANTY OF ANY KIND.  No author
  or distributor accepts any responsibility for the consequences of using it,
  or for whether it serves any particular purpose or works at all, unless he
  or she says so in writing.  Refer to the Aladdin Ghostscript Free Public
  License (the "License") for full details.
  
  Every copy of Aladdin Ghostscript must include a copy of the License,
  normally in a plain ASCII text file named PUBLIC.  The License grants you
  the right to copy, modify and redistribute Aladdin Ghostscript, but only
  under certain conditions described in the License.  Among other things, the
  License requires that the copyright notice and this notice be preserved on
  all copies.
*/

/* gxdevrop.h */
/* Extension of gxdevice.h for RasterOp */

/* Define an unaligned implementation of copy_rop. */
dev_proc_copy_rop(gx_copy_rop_unaligned);
dev_proc_strip_copy_rop(gx_strip_copy_rop_unaligned);

/* Define the default and forwarding implementations of [strip_]copy_rop. */
/* (Normally these are never referenced directly.) */
dev_proc_copy_rop(gx_real_default_copy_rop);
dev_proc_copy_rop(gx_forward_copy_rop);
dev_proc_strip_copy_rop(gx_real_default_strip_copy_rop);
dev_proc_strip_copy_rop(gx_forward_strip_copy_rop);
