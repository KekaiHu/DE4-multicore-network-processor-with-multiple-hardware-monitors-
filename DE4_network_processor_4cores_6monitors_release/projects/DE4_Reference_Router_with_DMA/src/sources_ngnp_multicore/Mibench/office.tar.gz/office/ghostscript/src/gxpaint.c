/* Copyright (C) 1995, 1996 Aladdin Enterprises.  All rights reserved.
  
  This file is part of Aladdin Ghostscript.
  
  Aladdin Ghostscript is distributed with NO WARRANTY OF ANY KIND.  No author
  or distributor accepts any responsibility for the consequences of using it,
  or for whether it serves any particular purpose or works at all, unless he
  or she says so in writing.  Refer to the Aladdin Ghostscript Free Public
  License (the "License") for full details.
  
  Every copy of Aladdin Ghostscript must include a copy of the License,
  normally in a plain ASCII text file named PUBLIC.  The License grants you
  the right to copy, modify and redistribute Aladdin Ghostscript, but only
  under certain conditions described in the License.  Among other things, the
  License requires that the copyright notice and this notice be preserved on
  all copies.
*/

/* gxpaint.c */
/* Graphics-state-aware fill and stroke procedures */
#include "gx.h"
#include "gzstate.h"
#include "gxdevice.h"
#include "gxhttile.h"
#include "gxpaint.h"
#include "gxpath.h"

/* Fill a path. */
int
gx_fill_path(gx_path *ppath, gx_device_color *pdevc, gs_state *pgs,
  int rule, fixed adjust_x, fixed adjust_y)
{	gx_device *dev = gs_currentdevice_inline(pgs);
	gx_fill_params params;

	params.rule = rule;
	params.adjust.x = adjust_x;
	params.adjust.y = adjust_y;
	params.flatness = (pgs->in_cachedevice > 1 ? 0.0 : pgs->flatness);
	params.fill_zero_width = (adjust_x | adjust_y) != 0;
	return (*dev_proc(dev, fill_path))
	  (dev, (const gs_imager_state *)pgs, ppath, &params, pdevc,
	   pgs->clip_path);
}

/* Stroke a path for drawing or saving. */
int
gx_stroke_fill(gx_path *ppath, gs_state *pgs)
{	gx_device *dev = gs_currentdevice_inline(pgs);
	gx_stroke_params params;

	params.flatness = (pgs->in_cachedevice > 1 ? 0.0 : pgs->flatness);
	return (*dev_proc(dev, stroke_path))
	  (dev, (const gs_imager_state *)pgs, ppath, &params,
	   pgs->dev_color, pgs->clip_path);
}

int
gx_stroke_add(gx_path *ppath, gx_path *to_path, gs_state *pgs)
{	gx_stroke_params params;

	params.flatness = (pgs->in_cachedevice > 1 ? 0.0 : pgs->flatness);
	return gx_stroke_path_only(ppath, to_path, pgs->device,
				   (const gs_imager_state *)pgs,
				   &params, NULL, NULL);
}
